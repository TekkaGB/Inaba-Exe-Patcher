﻿namespace AtlusFileSystemLibrary
{
    public interface INamedFileSystem : IFileSystem<string>
    {
    }
}