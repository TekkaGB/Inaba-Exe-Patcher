namespace AtlusFileSystemLibrary.FileSystems.SMT1
{
    public enum ContentKind
    {
        Unknown,
        TIM,
        TIMH,
        SC02,
        Archive,
    }
}