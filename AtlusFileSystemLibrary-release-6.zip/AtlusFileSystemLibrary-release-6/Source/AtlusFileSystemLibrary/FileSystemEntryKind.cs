﻿namespace AtlusFileSystemLibrary
{
    public enum FileSystemEntryKind
    {
        Directory,
        File
    }
}