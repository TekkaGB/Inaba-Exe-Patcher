namespace nQuant
{
    public struct Box
    {
        public byte AlphaMinimum;
        public byte AlphaMaximum;
        public byte RedMinimum;
        public byte RedMaximum;
        public byte GreenMinimum;
        public byte GreenMaximum;
        public byte BlueMinimum;
        public byte BlueMaximum;
        public int Size;
    }
}