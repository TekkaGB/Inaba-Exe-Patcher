namespace nQuant
{
    public class Lookup
    {
        public int Alpha;
        public int Red;
        public int Green;
        public int Blue;
    }
}