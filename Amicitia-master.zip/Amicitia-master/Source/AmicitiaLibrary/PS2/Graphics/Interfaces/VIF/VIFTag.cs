﻿namespace AmicitiaLibrary.PS2.Graphics.Interfaces.VIF
{
    public struct VifTag
    {
        // Fields
        public ushort Immediate;
        public byte Count;
        public byte Command;
    }
}
