﻿namespace AmicitiaLibrary.Graphics.TMX
{
    public enum TmxWrapMode : byte
    {
        Repeat = 0x00,
        Clamp = 0x01
    }
}
